package com.hwell.client.gui;

import com.hwell.client.HwellClient;
import com.hwell.client.core.ClientModule;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiScreen extends class_437 {
    private static final int PANEL_W = 230;
    private static final int ROW_H = 24;
    private int panelX, panelY;

    public ClickGuiScreen() { super(class_2561.method_43470("HWELL Client")); }
    @Override protected void method_25426() { panelX = (field_22789 - PANEL_W) / 2; panelY = (field_22790 - 80) / 2; }

    @Override public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Avoid vanilla blur: it can crash when another screen/mod already blurred this frame.
        ctx.method_25294(0, 0, field_22789, field_22790, 0x99000000);
        int panelH = 42 + HwellClient.MODULES.all().size() * ROW_H;
        ctx.method_25294(panelX, panelY, panelX + PANEL_W, panelY + panelH, 0xEE101014);
        ctx.method_25294(panelX, panelY, panelX + PANEL_W, panelY + 3, 0xFFE21B2D);
        ctx.method_51433(field_22793, "HWELL CLIENT", panelX + 12, panelY + 12, 0xFFFFFFFF, false);
        int y = panelY + 34;
        for (ClientModule module : HwellClient.MODULES.all()) {
            boolean hovered = mouseX >= panelX && mouseX <= panelX + PANEL_W && mouseY >= y && mouseY < y + ROW_H;
            ctx.method_25294(panelX + 6, y, panelX + PANEL_W - 6, y + ROW_H - 2,
                hovered ? 0xFF303039 : 0xFF1C1C23);
            ctx.method_51433(field_22793, module.name(), panelX + 14, y + 7, 0xFFFFFFFF, false);
            ctx.method_51433(field_22793, module.enabled() ? "ON" : "OFF", panelX + PANEL_W - 36,
                y + 7, module.enabled() ? 0xFF55FF88 : 0xFFAAAAAA, false);
            y += ROW_H;
        }
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();
        if (button == 0) {
            int y = panelY + 34;
            for (ClientModule module : HwellClient.MODULES.all()) {
                if (mouseX >= panelX && mouseX <= panelX + PANEL_W && mouseY >= y && mouseY < y + ROW_H) {
                    module.toggle(); return true;
                }
                y += ROW_H;
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override public boolean method_25404(class_11908 input) {
        int keyCode = input.comp_4795();
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { method_25419(); return true; }
        return super.method_25404(input);
    }
    @Override public boolean method_25421() { return false; }
}
