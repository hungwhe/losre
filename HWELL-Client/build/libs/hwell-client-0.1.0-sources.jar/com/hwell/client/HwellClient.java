package com.hwell.client;

import com.hwell.client.core.ModuleManager;
import com.hwell.client.gui.ClickGuiScreen;
import com.hwell.client.modules.ExampleModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class HwellClient implements ClientModInitializer {
    public static final String NAME = "HWELL";
    public static final ModuleManager MODULES = new ModuleManager();
    private class_304 openGuiKey;
    private static final class_304.class_11900 HWELL_CATEGORY =
        class_304.class_11900.method_74698(class_2960.method_60655("hwellclient", "main"));

    @Override public void onInitializeClient() {
        // Framework bootstrap. Existing Meteor module logic is retained in migration-reference;
        // each module must be ported from Meteor APIs before it can be registered here.
        MODULES.register(new ExampleModule());
        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.hwellclient.clickgui", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT,
            HWELL_CATEGORY));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.method_1436()) {
                if (client.field_1755 == null) client.method_1507(new ClickGuiScreen());
            }
            MODULES.tick();
        });
    }
}
